import React from 'react'
import SecondSection from '../components/SecondSection'

function BrandPage() {
  return (
    <div>
      <div className='brand-container'>
        <div className='brand-info'>
          <h1 className='brand-name'>Your Brand Name</h1>
          <p className='brand-description'>
            A little description of the brand goes here.
          </p>
          <button className='purchase-button'>Purchase Now</button>
        </div>
      </div>
     <SecondSection/>
    </div>
  )
}

export default BrandPage
